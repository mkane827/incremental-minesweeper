import { computed, DestroyRef, inject, Injectable, signal } from '@angular/core';
import { BoardConfig, Cell, GameStatus } from '../models/cell';
import {
  createCells,
  flagRemainingMines,
  floodReveal,
  isCleared,
  neighborIndexes,
  placeMines,
  revealMines,
} from './board.util';

export const DEFAULT_CONFIG: BoardConfig = { rows: 10, cols: 10, mines: 10 };

const MAX_ELAPSED = 999;

/**
 * Single source of truth for a round of minesweeper.
 *
 * All state lives in signals and every mutation replaces the cell array with a
 * new one (and new objects for the cells that changed), so `OnPush` children
 * bound to a single cell re-render only when that cell actually moves.
 */
@Injectable({ providedIn: 'root' })
export class GameStore {
  private readonly destroyRef = inject(DestroyRef);
  private timerId: ReturnType<typeof setInterval> | null = null;

  private readonly _config = signal<BoardConfig>(DEFAULT_CONFIG);
  private readonly _cells = signal<readonly Cell[]>(createCells(DEFAULT_CONFIG));
  private readonly _status = signal<GameStatus>('idle');
  private readonly _elapsedSeconds = signal(0);

  readonly config = this._config.asReadonly();
  readonly cells = this._cells.asReadonly();
  readonly status = this._status.asReadonly();
  readonly elapsedSeconds = this._elapsedSeconds.asReadonly();

  readonly flagCount = computed(
    () => this._cells().filter((cell) => cell.state === 'flagged').length,
  );

  /** Mines the player still has to account for (can go negative). */
  readonly minesRemaining = computed(() => this._config().mines - this.flagCount());

  readonly isOver = computed(() => {
    const status = this._status();
    return status === 'won' || status === 'lost';
  });

  readonly revealedCount = computed(
    () => this._cells().filter((cell) => cell.state === 'revealed').length,
  );

  constructor() {
    this.destroyRef.onDestroy(() => this.stopTimer());
  }

  /** Starts a fresh round, optionally with a different board size. */
  newGame(config: BoardConfig = this._config()): void {
    this.stopTimer();
    this._config.set(config);
    this._cells.set(createCells(config));
    this._status.set('idle');
    this._elapsedSeconds.set(0);
  }

  /** Left click: uncover a square (or chord, if it is already a number). */
  reveal(index: number): void {
    if (this.isOver()) {
      return;
    }

    let cells = this._cells();
    const target = cells[index];
    if (!target || target.state !== 'hidden') {
      return;
    }

    const config = this._config();

    // Mines are laid on the first click so the opening move is never fatal.
    if (this._status() === 'idle') {
      cells = placeMines(cells, config, index);
      this._status.set('playing');
      this.startTimer();
    }

    if (cells[index].isMine) {
      this._cells.set(revealMines(cells, index));
      this.finish('lost');
      return;
    }

    const next = floodReveal(cells, index, config);
    this._cells.set(next);
    this.settle(next);
  }

  /** Right click: cycle a square between hidden and flagged. */
  toggleFlag(index: number): void {
    if (this.isOver()) {
      return;
    }

    const cells = this._cells();
    const target = cells[index];
    if (!target || target.state === 'revealed') {
      return;
    }

    const next = cells.slice();
    next[index] = {
      ...target,
      state: target.state === 'flagged' ? 'hidden' : 'flagged',
    };
    this._cells.set(next);
  }

  /**
   * Clicking a revealed number whose flag count already matches uncovers the
   * rest of its neighbours in one go.
   */
  chord(index: number): void {
    if (this._status() !== 'playing') {
      return;
    }

    const cells = this._cells();
    const target = cells[index];
    if (!target || target.state !== 'revealed' || target.adjacentMines === 0) {
      return;
    }

    const config = this._config();
    const neighbors = neighborIndexes(index, config);
    const flagged = neighbors.filter((n) => cells[n].state === 'flagged').length;
    if (flagged !== target.adjacentMines) {
      return;
    }

    const toReveal = neighbors.filter((n) => cells[n].state === 'hidden');
    const detonated = toReveal.find((n) => cells[n].isMine);
    if (detonated !== undefined) {
      this._cells.set(revealMines(cells, detonated));
      this.finish('lost');
      return;
    }

    let next = cells;
    for (const n of toReveal) {
      next = floodReveal(next, n, config);
    }
    this._cells.set(next);
    this.settle(next);
  }

  private settle(cells: readonly Cell[]): void {
    if (isCleared(cells)) {
      this._cells.set(flagRemainingMines(cells));
      this.finish('won');
    }
  }

  private finish(status: Extract<GameStatus, 'won' | 'lost'>): void {
    this._status.set(status);
    this.stopTimer();
  }

  private startTimer(): void {
    this.stopTimer();
    this.timerId = setInterval(() => {
      this._elapsedSeconds.update((value) => Math.min(value + 1, MAX_ELAPSED));
    }, 1000);
  }

  private stopTimer(): void {
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }
}

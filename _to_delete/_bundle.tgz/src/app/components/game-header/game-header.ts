import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatIcon } from '@angular/material/icon';
import { MatIconButton } from '@angular/material/button';
import { MatTooltip } from '@angular/material/tooltip';
import { GameStore } from '../../services/game-store';

@Component({
  selector: 'ms-game-header',
  imports: [MatIcon, MatIconButton, MatTooltip],
  templateUrl: './game-header.html',
  styleUrl: './game-header.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GameHeader {
  private readonly store = inject(GameStore);

  protected readonly minesRemaining = this.store.minesRemaining;
  protected readonly status = this.store.status;

  protected readonly elapsed = computed(() => pad(this.store.elapsedSeconds()));
  protected readonly mineText = computed(() => {
    const remaining = this.minesRemaining();
    return remaining < 0 ? `-${pad(Math.abs(remaining))}` : pad(remaining);
  });

  protected readonly faceIcon = computed(() => {
    switch (this.status()) {
      case 'won':
        return 'sentiment_very_satisfied';
      case 'lost':
        return 'sentiment_very_dissatisfied';
      default:
        return 'mood';
    }
  });

  protected reset(): void {
    this.store.newGame();
  }
}

function pad(value: number): string {
  return Math.min(value, 999).toString().padStart(3, '0');
}

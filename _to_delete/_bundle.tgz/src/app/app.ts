import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatCard, MatCardContent } from '@angular/material/card';
import { MatToolbar } from '@angular/material/toolbar';
import { MatIcon } from '@angular/material/icon';
import { Board } from './components/board/board';
import { GameHeader } from './components/game-header/game-header';
import { GameStore } from './services/game-store';

@Component({
  selector: 'ms-root',
  imports: [MatCard, MatCardContent, MatToolbar, MatIcon, Board, GameHeader],
  templateUrl: './app.html',
  styleUrl: './app.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App {
  private readonly store = inject(GameStore);

  protected readonly status = this.store.status;

  protected readonly banner = computed(() => {
    switch (this.status()) {
      case 'won':
        return { icon: 'celebration', text: 'Board cleared. Nicely done.' };
      case 'lost':
        return {
          icon: 'sentiment_very_dissatisfied',
          text: 'Boom. Hit the face to try again.',
        };
      default:
        return null;
    }
  });
}
